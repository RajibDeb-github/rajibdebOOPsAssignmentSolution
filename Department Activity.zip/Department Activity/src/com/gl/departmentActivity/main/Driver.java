package com.gl.departmentActivity.main;

import com.gl.departmentActivity.services.AdminDepartment;
import com.gl.departmentActivity.services.HrDepartment;
import com.gl.departmentActivity.services.TechDepartment;

public class Driver {

	public static void main(String[] args) {
		// Create object
		AdminDepartment ad = new AdminDepartment(); // object of AdminDepartment
		HrDepartment hd = new HrDepartment(); // object of HrDepartment
		TechDepartment td = new TechDepartment(); // object of TechDepartment

		// Each department will display all its functionalities
		// **************AdminDepartment*****************************
		System.out.println("Welcome to "+ad.departmentName());
		System.out.println(ad.getTodaysWork());
		System.out.println(ad.getWorkDeadline());
		System.out.println(ad.isTodayAHoliday());
		
		System.out.println();  //blank line
		System.out.println();

		// *************HrDepartment*********************************
		System.out.println("Welcome to "+hd.departmentName());
		System.out.println(hd.doActivity());
		System.out.println(hd.getTodaysWork());
		System.out.println(hd.getWorkDeadline());
		System.out.println(hd.isTodayAHoliday());
		
		System.out.println();  //blank line
		System.out.println();

		// ************TechDepartment*********************************
		System.out.println("Welcome to "+td.departmentName());
		System.out.println(td.getTodaysWork());
		System.out.println(td.getWorkDeadline());
		System.out.println(td.getTechStackInformation());
		System.out.println(td.isTodayAHoliday());

	}

}
